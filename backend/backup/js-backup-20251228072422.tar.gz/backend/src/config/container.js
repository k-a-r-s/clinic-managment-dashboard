"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.container = exports.statsController = exports.machineController = exports.roomController = exports.medicalFileController = exports.appointementController = exports.userController = exports.patientController = exports.receptionistController = exports.doctorController = exports.authController = void 0;
var UserAuthService_1 = require("../application/services/UserAuthService");
var AuthRepository_1 = require("../infrastructure/repositories/AuthRepository");
var DoctorRepository_1 = require("../infrastructure/repositories/DoctorRepository");
var ReceptionistRepository_1 = require("../infrastructure/repositories/ReceptionistRepository");
var MedicalFileRepository_1 = require("../infrastructure/repositories/MedicalFileRepository");
var PatientRepository_1 = require("../infrastructure/repositories/PatientRepository");
var UserRepository_1 = require("../infrastructure/repositories/UserRepository");
var AppointementRepository_1 = require("../infrastructure/repositories/AppointementRepository");
var RoomRepository_1 = require("../infrastructure/repositories/RoomRepository");
var AppointmentHistoryRepository_1 = require("../infrastructure/repositories/AppointmentHistoryRepository");
// Controllers
var authController_1 = require("../interface/controllers/authController");
var doctorController_1 = require("../interface/controllers/doctorController");
var patientController_1 = require("../interface/controllers/patientController");
var userController_1 = require("../interface/controllers/userController");
var appointmentController_1 = require("../interface/controllers/appointmentController");
var medicalFileController_1 = require("../interface/controllers/medicalFileController");
var roomController_1 = require("../interface/controllers/roomController");
var MachineRepository_1 = require("../infrastructure/repositories/MachineRepository");
var CreateMachineUseCase_1 = require("../application/use-cases/machines/CreateMachineUseCase");
var GetAllMachinesUseCase_1 = require("../application/use-cases/machines/GetAllMachinesUseCase");
var GetMachineByIdUseCase_1 = require("../application/use-cases/machines/GetMachineByIdUseCase");
var UpdateMachineUseCase_1 = require("../application/use-cases/machines/UpdateMachineUseCase");
var DeactivateMachineUseCase_1 = require("../application/use-cases/machines/DeactivateMachineUseCase");
var GetMachineStatsUseCase_1 = require("../application/use-cases/machines/GetMachineStatsUseCase");
var GetMachineStatsFormattedUseCase_1 = require("../application/use-cases/machines/GetMachineStatsFormattedUseCase");
var machineController_1 = require("../interface/controllers/machineController");
var GetDashboardStatsUseCase_1 = require("../application/use-cases/stats/GetDashboardStatsUseCase");
var statsController_1 = require("../interface/controllers/statsController");
// Use Cases - Doctor
var GetAllDoctorsUseCase_1 = require("../application/use-cases/doctors/GetAllDoctorsUseCase");
var getDoctorUseCase_1 = require("../application/use-cases/doctors/getDoctorUseCase");
var DeleteDoctorByIdUseCase_1 = require("../application/use-cases/doctors/DeleteDoctorByIdUseCase");
var updateDoctorByIdUseCase_1 = require("../application/use-cases/doctors/updateDoctorByIdUseCase");
// Use Cases - Receptionists
var GetAllReceptionistsUseCase_1 = require("../application/use-cases/receptionists/GetAllReceptionistsUseCase");
var getReceptionistUseCase_1 = require("../application/use-cases/receptionists/getReceptionistUseCase");
var DeleteReceptionistByIdUseCase_1 = require("../application/use-cases/receptionists/DeleteReceptionistByIdUseCase");
var updateReceptionistByIdUseCase_1 = require("../application/use-cases/receptionists/updateReceptionistByIdUseCase");
var receptionistController_1 = require("../interface/controllers/receptionistController");
// Use Cases - Patient
var getPatientByIdUseCase_1 = require("../application/use-cases/patients/getPatientByIdUseCase");
var addPatientUseCase_1 = require("../application/use-cases/patients/addPatientUseCase");
var deletePatientByIdUseCase_1 = require("../application/use-cases/patients/deletePatientByIdUseCase");
var getAllPatientsUseCase_1 = require("../application/use-cases/patients/getAllPatientsUseCase");
var UpdatePatientUseCase_1 = require("../application/use-cases/patients/UpdatePatientUseCase");
// Use Cases - Medical File
var createMedicalFIleUseCase_1 = require("../application/use-cases/medicalFile/createMedicalFIleUseCase");
var GetMedicalFileUseCase_1 = require("../application/use-cases/medicalFile/GetMedicalFileUseCase");
var UpdateMedicalFileUseCase_1 = require("../application/use-cases/medicalFile/UpdateMedicalFileUseCase");
var DeleteMedicalFileUseCase_1 = require("../application/use-cases/medicalFile/DeleteMedicalFileUseCase");
// Use Cases - Appointment
var AddAppointementUseCase_1 = require("../application/use-cases/appointement/AddAppointementUseCase");
var GetAppointementsUseCase_1 = require("../application/use-cases/appointement/GetAppointementsUseCase");
var GetAppointmentsByDoctorUseCase_1 = require("../application/use-cases/appointement/GetAppointmentsByDoctorUseCase");
var GetAppointementsByPatientUseCase_1 = require("../application/use-cases/appointement/GetAppointementsByPatientUseCase");
var DeleteAppointmentUseCase_1 = require("../application/use-cases/appointement/DeleteAppointmentUseCase");
var GetAppointmentByIdUseCase_1 = require("../application/use-cases/appointement/GetAppointmentByIdUseCase");
// Use Cases - Room
var CreateRoom_1 = require("../application/use-cases/rooms/CreateRoom");
var GetRoomById_1 = require("../application/use-cases/rooms/GetRoomById");
var GetAllRooms_1 = require("../application/use-cases/rooms/GetAllRooms");
var GetAvailableRooms_1 = require("../application/use-cases/rooms/GetAvailableRooms");
var UpdateRoom_1 = require("../application/use-cases/rooms/UpdateRoom");
var DeleteRoom_1 = require("../application/use-cases/rooms/DeleteRoom");
var UpdateRoomAvailability_1 = require("../application/use-cases/rooms/UpdateRoomAvailability");
// Use Cases - Appointment History
var GetAppointmentHistoryforPatientUseCase_1 = require("../application/use-cases/AppointmentHistory/GetAppointmentHistoryforPatientUseCase");
var GetHistoriesByPatientUseCase_1 = require("../application/use-cases/AppointmentHistory/GetHistoriesByPatientUseCase");
var UpdateAppointmentHistoryUseCase_1 = require("../application/use-cases/AppointmentHistory/UpdateAppointmentHistoryUseCase");
var DeleteAppointmentHistoryUseCase_1 = require("../application/use-cases/AppointmentHistory/DeleteAppointmentHistoryUseCase");
var AppointmentCompletedUseCase_1 = require("../application/use-cases/AppointmentHistory/AppointmentCompletedUseCase");
// Repositories
var authRepository = new AuthRepository_1.AuthRepository();
var doctorRepository = new DoctorRepository_1.DoctorRepository();
var medicalFileRepository = new MedicalFileRepository_1.MedicalFileRepository();
var patientRepository = new PatientRepository_1.PatientRepository();
var userRepository = new UserRepository_1.UserRepository();
var appointementRepository = new AppointementRepository_1.AppointementRepository();
var roomRepository = new RoomRepository_1.RoomRepository();
var machineRepository = new MachineRepository_1.MachineRepository();
var appointmentHistoryRepository = new AppointmentHistoryRepository_1.AppointmentHistoryRepository();
// Services
var userAuthService = new UserAuthService_1.UserAuthService(userRepository, authRepository);
// Use Cases - Doctor
var getDoctorsListUseCase = new GetAllDoctorsUseCase_1.GetDoctorsListUseCase(doctorRepository);
var getDoctorUseCase = new getDoctorUseCase_1.GetDoctorUseCase(doctorRepository);
var deleteDoctorByIdUseCase = new DeleteDoctorByIdUseCase_1.DeleteDoctorByIdUseCase(doctorRepository);
var updateDoctorByIdUseCase = new updateDoctorByIdUseCase_1.UpdateDoctorByIdUseCase(doctorRepository);
// Receptionsits
var receptionistRepository = new ReceptionistRepository_1.ReceptionistRepository();
var getReceptionistsListUseCase = new GetAllReceptionistsUseCase_1.GetReceptionistsListUseCase(receptionistRepository);
var getReceptionistUseCase = new getReceptionistUseCase_1.GetReceptionistUseCase(receptionistRepository);
var deleteReceptionistByIdUseCase = new DeleteReceptionistByIdUseCase_1.DeleteReceptionistByIdUseCase(receptionistRepository);
var updateReceptionistByIdUseCase = new updateReceptionistByIdUseCase_1.UpdateReceptionistByIdUseCase(receptionistRepository);
// Use Cases - Medical File (without createMedicalFile for now)
var getMedicalFileUseCase = new GetMedicalFileUseCase_1.GetMedicalFileUseCase(medicalFileRepository);
var updateMedicalFileUseCaseInstance = new UpdateMedicalFileUseCase_1.UpdateMedicalFileUseCase(medicalFileRepository);
var deleteMedicalFileUseCase = new DeleteMedicalFileUseCase_1.DeleteMedicalFileUseCase(medicalFileRepository);
// Use Cases - Patient
var getPatientByIdUseCase = new getPatientByIdUseCase_1.GetPatientByIdUseCase(patientRepository);
var deletePatientByIdUseCase = new deletePatientByIdUseCase_1.DeletePatientByIdUseCase(patientRepository);
var getAllPatientsUseCase = new getAllPatientsUseCase_1.GetAllPatientsUseCase(patientRepository);
var updatePatientUseCase = new UpdatePatientUseCase_1.UpdatePatientUseCase(patientRepository);
// Create medical file use case (depends on patient use cases)
var createMedicalFileUseCaseInstance = new createMedicalFIleUseCase_1.createMedicalFileUseCase(medicalFileRepository, updatePatientUseCase, patientRepository);
// Add patient use case (depends on createMedicalFileUseCase)
var addPatientUseCase = new addPatientUseCase_1.AddPatientUseCase(patientRepository, createMedicalFileUseCaseInstance);
// Use Cases - Appointment
var addAppointementUseCase = new AddAppointementUseCase_1.AddAppointementUseCase(appointementRepository);
var getAppointementsUseCase = new GetAppointementsUseCase_1.GetAppointementsUseCase(appointementRepository);
var getAppointmentsByDoctorUseCase = new GetAppointmentsByDoctorUseCase_1.GetAppointmentsByDoctorUseCase(appointementRepository);
var getAppointementsByPatientUseCase = new GetAppointementsByPatientUseCase_1.GetAppointementsByPatientUseCase(appointementRepository);
var deleteAppointementUseCaseInstance = new DeleteAppointmentUseCase_1.deleteAppointementUseCase(appointementRepository);
var getAppointmentByIdUseCase = new GetAppointmentByIdUseCase_1.GetAppointmentByIdUseCase(appointementRepository);
// Use Cases - Room
var createRoomUseCase = new CreateRoom_1.CreateRoom(roomRepository);
var getRoomByIdUseCase = new GetRoomById_1.GetRoomById(roomRepository);
var getAllRoomsUseCase = new GetAllRooms_1.GetAllRooms(roomRepository);
var getAvailableRoomsUseCase = new GetAvailableRooms_1.GetAvailableRooms(roomRepository);
var updateRoomUseCase = new UpdateRoom_1.UpdateRoom(roomRepository);
var deleteRoomUseCase = new DeleteRoom_1.DeleteRoom(roomRepository);
var updateRoomAvailabilityUseCase = new UpdateRoomAvailability_1.UpdateRoomAvailability(roomRepository);
// Use Cases - Machines
var createMachineUseCase = new CreateMachineUseCase_1.CreateMachineUseCase(machineRepository);
var getAllMachinesUseCase = new GetAllMachinesUseCase_1.GetAllMachinesUseCase(machineRepository);
var getMachineByIdUseCase = new GetMachineByIdUseCase_1.GetMachineByIdUseCase(machineRepository);
var updateMachineUseCase = new UpdateMachineUseCase_1.UpdateMachineUseCase(machineRepository);
var deactivateMachineUseCase = new DeactivateMachineUseCase_1.DeactivateMachineUseCase(machineRepository);
var getMachineStatsUseCase = new GetMachineStatsUseCase_1.GetMachineStatsUseCase(machineRepository);
var getMachineStatsFormattedUseCase = new GetMachineStatsFormattedUseCase_1.GetMachineStatsFormattedUseCase(machineRepository);
var getDashboardStatsUseCase = new GetDashboardStatsUseCase_1.GetDashboardStatsUseCase(patientRepository, appointementRepository, machineRepository, userRepository);
// Use Cases - Appointment History
var getAppointmentHistoryUseCase = new GetAppointmentHistoryforPatientUseCase_1.GetAppointmentHistoryforPatientUseCase(appointmentHistoryRepository, appointementRepository);
var getHistoriesByPatientUseCase = new GetHistoriesByPatientUseCase_1.GetHistoriesByPatientUseCase(appointmentHistoryRepository);
var updateAppointmentHistoryUseCase = new UpdateAppointmentHistoryUseCase_1.UpdateAppointmentHistoryUseCase(appointmentHistoryRepository);
var deleteAppointmentHistoryUseCase = new DeleteAppointmentHistoryUseCase_1.DeleteAppointmentHistoryUseCase(appointmentHistoryRepository);
var appointmentCompletedUseCase = new AppointmentCompletedUseCase_1.AppointmentCompletedUseCase(appointmentHistoryRepository, medicalFileRepository, getMedicalFileUseCase, createMedicalFileUseCaseInstance);
// Controllers
exports.authController = new authController_1.AuthController(userAuthService);
exports.doctorController = new doctorController_1.DoctorController(getDoctorsListUseCase, deleteDoctorByIdUseCase, getDoctorUseCase, updateDoctorByIdUseCase);
exports.receptionistController = new receptionistController_1.ReceptionistController(getReceptionistsListUseCase, deleteReceptionistByIdUseCase, getReceptionistUseCase, updateReceptionistByIdUseCase);
exports.patientController = new patientController_1.PatientController(addPatientUseCase, getPatientByIdUseCase, deletePatientByIdUseCase, getAllPatientsUseCase, updatePatientUseCase);
exports.userController = new userController_1.UserController(userAuthService);
exports.appointementController = new appointmentController_1.AppointementController(addAppointementUseCase, getAppointementsUseCase, getAppointmentsByDoctorUseCase, getAppointementsByPatientUseCase, deleteAppointementUseCaseInstance, getAppointmentByIdUseCase, getAppointmentHistoryUseCase, getHistoriesByPatientUseCase, updateAppointmentHistoryUseCase, deleteAppointmentHistoryUseCase, appointmentCompletedUseCase);
exports.medicalFileController = new medicalFileController_1.MedicalFileController(createMedicalFileUseCaseInstance, getMedicalFileUseCase, updateMedicalFileUseCaseInstance, deleteMedicalFileUseCase);
exports.roomController = new roomController_1.RoomController(createRoomUseCase, getRoomByIdUseCase, getAllRoomsUseCase, getAvailableRoomsUseCase, updateRoomUseCase, deleteRoomUseCase, updateRoomAvailabilityUseCase);
exports.machineController = new machineController_1.MachineController(createMachineUseCase, getAllMachinesUseCase, getMachineByIdUseCase, updateMachineUseCase, deactivateMachineUseCase, getMachineStatsUseCase, getMachineStatsFormattedUseCase);
exports.statsController = new statsController_1.StatsController(getDashboardStatsUseCase);
// Dependency Injection Container
var Container = /** @class */ (function () {
    function Container() {
        this.dependencies = new Map();
    }
    Container.prototype.register = function (name, dependency) {
        this.dependencies.set(name, dependency);
    };
    Container.prototype.resolve = function (name) {
        if (!this.dependencies.has(name)) {
            throw new Error("Dependency ".concat(name, " not found"));
        }
        return this.dependencies.get(name);
    };
    return Container;
}());
exports.container = new Container();
// Register all controllers
exports.container.register('authController', exports.authController);
exports.container.register('doctorController', exports.doctorController);
exports.container.register('receptionistController', exports.receptionistController);
exports.container.register('patientController', exports.patientController);
exports.container.register('userController', exports.userController);
exports.container.register('appointementController', exports.appointementController);
exports.container.register('medicalFileController', exports.medicalFileController);
exports.container.register('roomController', exports.roomController);
exports.container.register('machineController', exports.machineController);
exports.container.register('statsController', exports.statsController);
