"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Machine = void 0;
var Machine = /** @class */ (function () {
    function Machine(props) {
        this.props = props;
    }
    Machine.prototype.getId = function () {
        return this.props.id;
    };
    Machine.prototype.getMachineId = function () {
        return this.props.machineId;
    };
    Machine.prototype.getManufacturer = function () {
        return this.props.manufacturer;
    };
    Machine.prototype.getModel = function () {
        return this.props.model;
    };
    Machine.prototype.getStatus = function () {
        return this.props.status;
    };
    Machine.prototype.getLastMaintenanceDate = function () {
        return this.props.lastMaintenanceDate;
    };
    Machine.prototype.getNextMaintenanceDate = function () {
        return this.props.nextMaintenanceDate;
    };
    Machine.prototype.getIsActive = function () {
        return this.props.isActive;
    };
    Machine.prototype.getRoomId = function () {
        return this.props.roomId;
    };
    Machine.prototype.toJson = function () {
        return {
            id: this.props.id,
            machineId: this.props.machineId,
            manufacturer: this.props.manufacturer,
            model: this.props.model,
            status: this.props.status,
            lastMaintenanceDate: this.props.lastMaintenanceDate,
            nextMaintenanceDate: this.props.nextMaintenanceDate,
            isActive: this.props.isActive,
            roomId: this.props.roomId,
            createdAt: this.props.createdAt,
            updatedAt: this.props.updatedAt,
        };
    };
    return Machine;
}());
exports.Machine = Machine;
