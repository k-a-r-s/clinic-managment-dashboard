"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MedicalFile = void 0;
var MedicalFile = /** @class */ (function () {
    function MedicalFile(doctorId, data, id) {
        if (id) {
            this.id = id;
        }
        else {
            this.id = crypto.randomUUID();
        }
        this.doctorId = doctorId;
        this.data = data;
    }
    MedicalFile.prototype.getDoctorId = function () {
        return this.doctorId;
    };
    MedicalFile.prototype.getData = function () {
        return this.data;
    };
    return MedicalFile;
}());
exports.MedicalFile = MedicalFile;
