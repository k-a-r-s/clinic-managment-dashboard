"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Patient = void 0;
var date_fns_1 = require("date-fns");
var Patient = /** @class */ (function () {
    function Patient(props) {
        this.props = props;
    }
    Patient.prototype.getId = function () {
        return this.props.id;
    };
    Patient.prototype.getMedicalFileId = function () {
        return this.props.medicalFileId;
    };
    Patient.prototype.getFirstName = function () {
        return this.props.firstName;
    };
    Patient.prototype.getLastName = function () {
        return this.props.lastName;
    };
    Patient.prototype.getEmail = function () {
        return this.props.email;
    };
    Patient.prototype.getPhoneNumber = function () {
        return this.props.phoneNumber;
    };
    Patient.prototype.getBirthDate = function () {
        return this.props.birthDate;
    };
    Patient.prototype.getGender = function () {
        return this.props.gender;
    };
    Patient.prototype.getAddress = function () {
        return this.props.address;
    };
    Patient.prototype.getProfession = function () {
        return this.props.profession;
    };
    Patient.prototype.getChildrenNumber = function () {
        return this.props.childrenNumber;
    };
    Patient.prototype.getFamilySituation = function () {
        return this.props.familySituation;
    };
    Patient.prototype.getInsuranceNumber = function () {
        return this.props.insuranceNumber;
    };
    Patient.prototype.getEmergencyContactName = function () {
        return this.props.emergencyContactName;
    };
    Patient.prototype.getEmergencyContactPhone = function () {
        return this.props.emergencyContactPhone;
    };
    Patient.prototype.getAge = function () {
        return (0, date_fns_1.differenceInYears)(new Date(), new Date(this.props.birthDate));
    };
    Patient.prototype.toJson = function () {
        return {
            id: this.props.id,
            firstName: this.props.firstName,
            lastName: this.props.lastName,
            email: this.props.email,
            phoneNumber: this.props.phoneNumber,
            birthDate: this.props.birthDate,
            age: this.getAge(),
            gender: this.props.gender,
            address: this.props.address,
            profession: this.props.profession,
            childrenNumber: this.props.childrenNumber,
            familySituation: this.props.familySituation,
            insuranceNumber: this.props.insuranceNumber,
            emergencyContactName: this.props.emergencyContactName,
            emergencyContactPhone: this.props.emergencyContactPhone,
            MedicalFileId: this.props.medicalFileId,
        };
    };
    return Patient;
}());
exports.Patient = Patient;
