"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Room = void 0;
var Room = /** @class */ (function () {
    function Room(id, roomNumber, capacity, type, isAvailable, createdAt, updatedAt) {
        this.id = id;
        this.roomNumber = roomNumber;
        this.capacity = capacity;
        this.type = type;
        this.isAvailable = isAvailable;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    Room.prototype.getId = function () {
        return this.id;
    };
    Room.prototype.getRoomNumber = function () {
        return this.roomNumber;
    };
    Room.prototype.getCapacity = function () {
        return this.capacity;
    };
    Room.prototype.getType = function () {
        return this.type;
    };
    Room.prototype.getIsAvailable = function () {
        return this.isAvailable;
    };
    Room.prototype.getCreatedAt = function () {
        return this.createdAt;
    };
    Room.prototype.getUpdatedAt = function () {
        return this.updatedAt;
    };
    Room.prototype.toJSON = function () {
        return {
            id: this.id,
            roomNumber: this.roomNumber,
            capacity: this.capacity,
            type: this.type,
            isAvailable: this.isAvailable,
            createdAt: this.createdAt,
            updatedAt: this.updatedAt,
        };
    };
    return Room;
}());
exports.Room = Room;
