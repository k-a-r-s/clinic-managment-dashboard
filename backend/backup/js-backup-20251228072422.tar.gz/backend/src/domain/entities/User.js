"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = void 0;
var User = /** @class */ (function () {
    function User(id, email, firstName, lastName, role // ✅ Accept string
    ) {
        // Validate role at construction time
        var validRoles = ["admin", "doctor", "receptionist"];
        if (!validRoles.includes(role)) {
            throw new Error("Invalid role: ".concat(role, ". Must be one of: ").concat(validRoles.join(", ")));
        }
        this.id = id;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.role = role;
    }
    // Getters
    User.prototype.getId = function () {
        return this.id;
    };
    User.prototype.getEmail = function () {
        return this.email;
    };
    User.prototype.getFirstName = function () {
        return this.firstName;
    };
    User.prototype.getLastName = function () {
        return this.lastName;
    };
    User.prototype.getRole = function () {
        return this.role;
    };
    User.fromDataBase = function (data) {
        return new User(data.id, data.email, data.first_name, data.last_name, data.role // Validation happens in constructor
        );
    };
    User.prototype.toJSON = function () {
        return {
            id: this.id,
            email: this.email,
            firstName: this.firstName,
            lastName: this.lastName,
            role: this.role,
        };
    };
    return User;
}());
exports.User = User;
