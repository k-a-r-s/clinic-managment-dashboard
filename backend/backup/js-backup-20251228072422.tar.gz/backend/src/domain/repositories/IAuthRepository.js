"use strict";
// the difference between this class and user class is that this class is responsible for authentication and authorization
// while user class is responsible for user management
Object.defineProperty(exports, "__esModule", { value: true });
