"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthError = void 0;
var AppError_1 = require("./AppError");
var AuthErrorType;
(function (AuthErrorType) {
    AuthErrorType["INVALID_CREDENTIALS"] = "INVALID_CREDENTIALS";
    AuthErrorType["USER_NOT_FOUND"] = "USER_NOT_FOUND";
    AuthErrorType["USER_ALREADY_EXISTS"] = "USER_ALREADY_EXISTS";
    AuthErrorType["TOKEN_EXPIRED"] = "TOKEN_EXPIRED";
    AuthErrorType["INVALID_TOKEN"] = "INVALID_TOKEN";
    AuthErrorType["UNAUTHORIZED"] = "UNAUTHORIZED";
    AuthErrorType["FORBIDDEN"] = "FORBIDDEN";
    AuthErrorType["PASSWORD_MISMATCH"] = "PASSWORD_MISMATCH";
    AuthErrorType["EMAIL_NOT_VERIFIED"] = "EMAIL_NOT_VERIFIED";
    AuthErrorType["ACCOUNT_LOCKED"] = "ACCOUNT_LOCKED";
})(AuthErrorType || (AuthErrorType = {}));
var AuthError = /** @class */ (function (_super) {
    __extends(AuthError, _super);
    function AuthError(message, context, subErrorType) {
        var _this = _super.call(this, message, context) || this;
        _this.subErrorType = subErrorType;
        // Maintain proper prototype chain for instanceof checks
        Object.setPrototypeOf(_this, AuthError.prototype);
        return _this;
    }
    AuthError.invalidCredentials = function (context) {
        return new AuthError("Invalid credentials provided.", context, AuthErrorType.INVALID_CREDENTIALS);
    };
    AuthError.userNotFound = function (context) {
        return new AuthError("User not found.", context, AuthErrorType.USER_NOT_FOUND);
    };
    AuthError.userAlreadyExists = function (context) {
        return new AuthError("User already exists.", context, AuthErrorType.USER_ALREADY_EXISTS);
    };
    AuthError.tokenExpired = function (context) {
        return new AuthError("Authentication token has expired.", context, AuthErrorType.TOKEN_EXPIRED);
    };
    AuthError.invalidToken = function (context) {
        return new AuthError("Invalid authentication token.", context, AuthErrorType.INVALID_TOKEN);
    };
    AuthError.unauthorized = function (context) {
        return new AuthError("Unauthorized access.", context, AuthErrorType.UNAUTHORIZED);
    };
    AuthError.forbidden = function (context) {
        return new AuthError("Forbidden access.", context, AuthErrorType.FORBIDDEN);
    };
    AuthError.passwordMismatch = function (context) {
        return new AuthError("Password does not match.", context, AuthErrorType.PASSWORD_MISMATCH);
    };
    AuthError.emailNotVerified = function (context) {
        return new AuthError("Email address is not verified.", context, AuthErrorType.EMAIL_NOT_VERIFIED);
    };
    AuthError.accountLocked = function (context) {
        return new AuthError("Account is locked.", context, AuthErrorType.ACCOUNT_LOCKED);
    };
    return AuthError;
}(AppError_1.AppError));
exports.AuthError = AuthError;
