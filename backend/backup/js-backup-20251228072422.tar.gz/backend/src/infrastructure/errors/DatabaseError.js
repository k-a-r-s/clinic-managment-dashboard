"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseError = exports.DatabaseErrorType = void 0;
var AppError_1 = require("./AppError");
var DatabaseErrorType;
(function (DatabaseErrorType) {
    DatabaseErrorType["INVALID_LOGIN_CREDENTIALS"] = "Invalid login credentials";
    DatabaseErrorType["USER_ALREADY_REGISTERED"] = "User already registered";
    DatabaseErrorType["PASSWORD_TOO_SHORT"] = "Password should be at least 6 characters";
    DatabaseErrorType["INVALID_TOKEN"] = "Invalid token";
    DatabaseErrorType["USER_NOT_CONFIRMED"] = "User not confirmed";
    DatabaseErrorType["RATE_LIMIT_EXCEEDED"] = "Too many requests";
})(DatabaseErrorType || (exports.DatabaseErrorType = DatabaseErrorType = {}));
var DatabaseError = /** @class */ (function (_super) {
    __extends(DatabaseError, _super);
    function DatabaseError(errorOrMessage, fallbackMessage) {
        var _this = this;
        var message = typeof errorOrMessage === "string"
            ? errorOrMessage
            : (errorOrMessage === null || errorOrMessage === void 0 ? void 0 : errorOrMessage.message) ||
                fallbackMessage ||
                "Database error occurred";
        _this = _super.call(this, message) || this;
        _this.status =
            typeof errorOrMessage === "string" ? 500 : (errorOrMessage === null || errorOrMessage === void 0 ? void 0 : errorOrMessage.status) || 500;
        _this.details =
            typeof errorOrMessage === "string" ? undefined : errorOrMessage === null || errorOrMessage === void 0 ? void 0 : errorOrMessage.details;
        _this.hint =
            typeof errorOrMessage === "string" ? undefined : errorOrMessage === null || errorOrMessage === void 0 ? void 0 : errorOrMessage.hint;
        _this.name = "DatabaseError";
        Object.setPrototypeOf(_this, AppError_1.AppError.prototype);
        return _this;
    }
    return DatabaseError;
}(AppError_1.AppError));
exports.DatabaseError = DatabaseError;
