"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReceptionistRepository = void 0;
var Receptionist_1 = require("../../domain/entities/Receptionist");
var supabase_1 = require("../database/supabase");
var logger_1 = require("../../shared/utils/logger");
var DatabaseError_1 = require("../errors/DatabaseError");
var ReceptionistRepository = /** @class */ (function () {
    function ReceptionistRepository() {
    }
    ReceptionistRepository.prototype.getReceptionistById = function (id) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, data, error, profile, r;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, supabase_1.supabaseAdmin
                            .from("receptionists")
                            .select("\n        id,\n        phone_number,\n        profiles!inner (\n          first_name,\n          last_name,\n          email,\n          role\n        )\n      ")
                            .eq("id", id)
                            .single()];
                    case 1:
                        _a = _b.sent(), data = _a.data, error = _a.error;
                        if (error) {
                            logger_1.Logger.error("Receptionist not fetched", { error: error });
                            throw new DatabaseError_1.DatabaseError(error.message);
                        }
                        if (!data)
                            return [2 /*return*/, null];
                        profile = data.profiles;
                        r = new Receptionist_1.Receptionist(data.id, profile.email, profile.first_name, profile.last_name);
                        if (data.phone_number)
                            r.setPhoneNumber(data.phone_number);
                        return [2 /*return*/, r];
                }
            });
        });
    };
    ReceptionistRepository.prototype.getReceptionists = function (offset, limit) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, count, countError, _b, data, error, receptionists;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0: return [4 /*yield*/, supabase_1.supabaseAdmin
                            .from("receptionists")
                            .select("*", { count: "exact", head: true })];
                    case 1:
                        _a = _c.sent(), count = _a.count, countError = _a.error;
                        if (countError) {
                            logger_1.Logger.error("Failed to get receptionists count", { countError: countError });
                            throw new DatabaseError_1.DatabaseError(countError.message);
                        }
                        return [4 /*yield*/, supabase_1.supabaseAdmin
                                .from("receptionists")
                                .select("\n        id,\n        phone_number,\n        profiles!inner (\n          first_name,\n          last_name,\n          email\n        )\n      ")
                                .range(offset, offset + limit - 1)];
                    case 2:
                        _b = _c.sent(), data = _b.data, error = _b.error;
                        if (error) {
                            logger_1.Logger.error("Receptionists not fetched", { error: error });
                            throw new DatabaseError_1.DatabaseError(error.message);
                        }
                        receptionists = (data || []).map(function (rec) {
                            var profile = rec.profiles;
                            return {
                                id: rec.id,
                                first_name: profile.first_name,
                                last_name: profile.last_name,
                                email: profile.email,
                                phone_number: rec.phone_number,
                            };
                        });
                        return [2 /*return*/, {
                                total: count || 0,
                                receptionists: receptionists,
                            }];
                }
            });
        });
    };
    ReceptionistRepository.prototype.updateReceptionistById = function (id, receptionistData) {
        return __awaiter(this, void 0, void 0, function () {
            var payload, profileUpdate, receptionistUpdate, profileError, recError, updated;
            var _a, _b;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        payload = receptionistData;
                        profileUpdate = {};
                        receptionistUpdate = {};
                        if ((_a = payload.firstName) !== null && _a !== void 0 ? _a : payload["first_name"]) {
                            profileUpdate.first_name = payload.firstName || payload["first_name"];
                        }
                        if ((_b = payload.lastName) !== null && _b !== void 0 ? _b : payload["last_name"]) {
                            profileUpdate.last_name = payload.lastName || payload["last_name"];
                        }
                        if (payload.email)
                            profileUpdate.email = payload.email;
                        if (payload.phoneNumber !== undefined || payload.phone_number !== undefined) {
                            receptionistUpdate.phone_number = payload.phoneNumber || payload.phone_number;
                        }
                        if (!(Object.keys(profileUpdate).length > 0)) return [3 /*break*/, 2];
                        return [4 /*yield*/, supabase_1.supabaseAdmin.from("profiles").update(profileUpdate).eq("id", id)];
                    case 1:
                        profileError = (_c.sent()).error;
                        if (profileError) {
                            logger_1.Logger.error("Profile not updated", { profileError: profileError });
                            throw new DatabaseError_1.DatabaseError(profileError.message);
                        }
                        _c.label = 2;
                    case 2:
                        if (!(Object.keys(receptionistUpdate).length > 0)) return [3 /*break*/, 4];
                        return [4 /*yield*/, supabase_1.supabaseAdmin.from("receptionists").update(receptionistUpdate).eq("id", id)];
                    case 3:
                        recError = (_c.sent()).error;
                        if (recError) {
                            logger_1.Logger.error("Receptionist not updated", { recError: recError });
                            throw new DatabaseError_1.DatabaseError(recError.message);
                        }
                        _c.label = 4;
                    case 4: return [4 /*yield*/, this.getReceptionistById(id)];
                    case 5:
                        updated = _c.sent();
                        if (!updated) {
                            logger_1.Logger.error("Receptionist not found after update", { id: id });
                            throw new DatabaseError_1.DatabaseError("Receptionist not found after update");
                        }
                        return [2 /*return*/, updated];
                }
            });
        });
    };
    ReceptionistRepository.prototype.deleteReceptionistById = function (id) {
        return __awaiter(this, void 0, void 0, function () {
            var error;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, supabase_1.supabaseAdmin.from("receptionists").delete().eq("id", id)];
                    case 1:
                        error = (_a.sent()).error;
                        if (error) {
                            logger_1.Logger.error("Receptionist not deleted", { error: error });
                            throw new DatabaseError_1.DatabaseError(error.message);
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    return ReceptionistRepository;
}());
exports.ReceptionistRepository = ReceptionistRepository;
