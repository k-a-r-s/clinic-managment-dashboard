"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppointementController = void 0;
var ResponseFormatter_1 = require("../utils/ResponseFormatter");
var AppointementController = /** @class */ (function () {
    function AppointementController(addAppointementUseCase, getAppointementsUseCase, getAppointementsByDoctorUseCase, getAppointementsByPatientUseCase, deleteAppointementUseCase, getAppointmentByIdUseCase, getAppointmentHistoryUseCase, getHistoriesByPatientUseCase, updateAppointmentHistoryUseCase, deleteAppointmentHistoryUseCase, appointmentCompletedUseCase) {
        this.addAppointementUseCase = addAppointementUseCase;
        this.getAppointementsUseCase = getAppointementsUseCase;
        this.getAppointementsByDoctorUseCase = getAppointementsByDoctorUseCase;
        this.getAppointementsByPatientUseCase = getAppointementsByPatientUseCase;
        this.deleteAppointementUseCase = deleteAppointementUseCase;
        this.getAppointmentByIdUseCase = getAppointmentByIdUseCase;
        this.getAppointmentHistoryUseCase = getAppointmentHistoryUseCase;
        this.getHistoriesByPatientUseCase = getHistoriesByPatientUseCase;
        this.updateAppointmentHistoryUseCase = updateAppointmentHistoryUseCase;
        this.deleteAppointmentHistoryUseCase = deleteAppointmentHistoryUseCase;
        this.appointmentCompletedUseCase = appointmentCompletedUseCase;
    }
    AppointementController.prototype.createAppointment = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var body;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        body = request.body;
                        return [4 /*yield*/, this.addAppointementUseCase.execute(body)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, ResponseFormatter_1.ResponseFormatter.success(response, null, "Appointment created successfully", 201)];
                }
            });
        });
    };
    AppointementController.prototype.getAllAppointments = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, _b, view, patientName, doctorName, filters, appointments;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        _a = request.query, _b = _a.view, view = _b === void 0 ? "month" : _b, patientName = _a.patientName, doctorName = _a.doctorName;
                        filters = {
                            patientName: patientName,
                            doctorName: doctorName
                        };
                        return [4 /*yield*/, this.getAppointementsUseCase.execute(view, filters)];
                    case 1:
                        appointments = _c.sent();
                        return [2 /*return*/, ResponseFormatter_1.ResponseFormatter.success(response, appointments, "Appointments retrieved successfully")];
                }
            });
        });
    };
    AppointementController.prototype.getAppointmentById = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var appointmentId, appointment;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        appointmentId = request.params.appointmentId;
                        return [4 /*yield*/, this.getAppointmentByIdUseCase.execute(appointmentId)];
                    case 1:
                        appointment = _a.sent();
                        if (!appointment) {
                            return [2 /*return*/, ResponseFormatter_1.ResponseFormatter.error(response, null, 404, "Appointment not found")];
                        }
                        return [2 /*return*/, ResponseFormatter_1.ResponseFormatter.success(response, appointment, "Appointment retrieved successfully")];
                }
            });
        });
    };
    AppointementController.prototype.getAppointmentsByDoctor = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var doctorId, _a, view, appointments;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        doctorId = request.params.doctorId;
                        _a = request.query.view, view = _a === void 0 ? "month" : _a;
                        return [4 /*yield*/, this.getAppointementsByDoctorUseCase.execute(doctorId, view)];
                    case 1:
                        appointments = _b.sent();
                        return [2 /*return*/, ResponseFormatter_1.ResponseFormatter.success(response, appointments, "Doctor appointments retrieved successfully")];
                }
            });
        });
    };
    AppointementController.prototype.getAppointmentsByPatient = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var patientId, _a, view, appointments;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        patientId = request.params.patientId;
                        _a = request.query.view, view = _a === void 0 ? "month" : _a;
                        return [4 /*yield*/, this.getAppointementsByPatientUseCase.execute(patientId, view)];
                    case 1:
                        appointments = _b.sent();
                        return [2 /*return*/, ResponseFormatter_1.ResponseFormatter.success(response, appointments, "Patient appointments retrieved successfully")];
                }
            });
        });
    };
    AppointementController.prototype.deleteAppointment = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var appointmentId;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        appointmentId = request.params.appointmentId;
                        return [4 /*yield*/, this.deleteAppointementUseCase.execute(appointmentId)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, ResponseFormatter_1.ResponseFormatter.success(response, null, "Appointment deleted successfully")];
                }
            });
        });
    };
    AppointementController.prototype.getHistoryByAppointmentId = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var appointmentId, history_1, error_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        appointmentId = request.params.appointmentId;
                        return [4 /*yield*/, this.getAppointmentHistoryUseCase.execute(appointmentId)];
                    case 1:
                        history_1 = _a.sent();
                        if (!history_1) {
                            ResponseFormatter_1.ResponseFormatter.error(response, { type: 'NOT_FOUND', message: 'Appointment history not found' }, 404, 'Appointment history not found');
                            return [2 /*return*/];
                        }
                        ResponseFormatter_1.ResponseFormatter.success(response, history_1.toJson(), 'Appointment history retrieved successfully', 200);
                        return [3 /*break*/, 3];
                    case 2:
                        error_1 = _a.sent();
                        ResponseFormatter_1.ResponseFormatter.error(response, { type: 'FETCH_ERROR', message: String(error_1) }, 400, 'Failed to retrieve appointment history');
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    AppointementController.prototype.getHistoriesByPatientId = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var patientId, histories, error_2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        patientId = request.params.patientId;
                        return [4 /*yield*/, this.getHistoriesByPatientUseCase.execute(patientId)];
                    case 1:
                        histories = _a.sent();
                        ResponseFormatter_1.ResponseFormatter.success(response, histories.map(function (h) { return h.toJson(); }), 'Appointment histories retrieved successfully', 200);
                        return [3 /*break*/, 3];
                    case 2:
                        error_2 = _a.sent();
                        ResponseFormatter_1.ResponseFormatter.error(response, { type: 'FETCH_ERROR', message: String(error_2) }, 400, 'Failed to retrieve appointment histories');
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    AppointementController.prototype.updateHistory = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var appointmentId, appointmentData, updatedHistory, error_3;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        appointmentId = request.params.appointmentId;
                        appointmentData = request.body.appointmentData;
                        return [4 /*yield*/, this.updateAppointmentHistoryUseCase.execute(appointmentId, appointmentData)];
                    case 1:
                        updatedHistory = _a.sent();
                        ResponseFormatter_1.ResponseFormatter.success(response, updatedHistory.toJson(), 'Appointment history updated successfully', 200);
                        return [3 /*break*/, 3];
                    case 2:
                        error_3 = _a.sent();
                        ResponseFormatter_1.ResponseFormatter.error(response, { type: 'UPDATE_ERROR', message: String(error_3) }, 400, 'Failed to update appointment history');
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    AppointementController.prototype.deleteHistory = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var appointmentId, error_4;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        appointmentId = request.params.appointmentId;
                        return [4 /*yield*/, this.deleteAppointmentHistoryUseCase.execute(appointmentId)];
                    case 1:
                        _a.sent();
                        ResponseFormatter_1.ResponseFormatter.success(response, null, 'Appointment history deleted successfully', 200);
                        return [3 /*break*/, 3];
                    case 2:
                        error_4 = _a.sent();
                        ResponseFormatter_1.ResponseFormatter.error(response, { type: 'DELETE_ERROR', message: String(error_4) }, 400, 'Failed to delete appointment history');
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    AppointementController.prototype.completeAppointment = function (request, response) {
        return __awaiter(this, void 0, void 0, function () {
            var appointmentId, _a, appointmentData, patientId, doctorId, medicalFileData, error_5;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _b.trys.push([0, 2, , 3]);
                        appointmentId = request.params.appointmentId;
                        _a = request.body, appointmentData = _a.appointmentData, patientId = _a.patientId, doctorId = _a.doctorId;
                        // If patientId and doctorId are not provided, they should be included in the request
                        // Otherwise, you would need to fetch them from the appointment
                        if (!patientId || !doctorId) {
                            ResponseFormatter_1.ResponseFormatter.error(response, { type: 'VALIDATION_ERROR', message: 'patientId and doctorId are required' }, 400, 'patientId and doctorId are required in request body');
                            return [2 /*return*/];
                        }
                        medicalFileData = {
                            patientId: patientId,
                            doctorId: doctorId,
                            data: appointmentData || {}
                        };
                        return [4 /*yield*/, this.appointmentCompletedUseCase.execute(medicalFileData, appointmentId)];
                    case 1:
                        _b.sent();
                        ResponseFormatter_1.ResponseFormatter.success(response, null, 'Appointment completed and history recorded successfully', 200);
                        return [3 /*break*/, 3];
                    case 2:
                        error_5 = _b.sent();
                        ResponseFormatter_1.ResponseFormatter.error(response, { type: 'COMPLETION_ERROR', message: String(error_5) }, 400, 'Failed to complete appointment');
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    return AppointementController;
}());
exports.AppointementController = AppointementController;
