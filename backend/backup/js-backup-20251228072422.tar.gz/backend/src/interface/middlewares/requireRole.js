"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireRole = void 0;
var AuthError_1 = require("../../infrastructure/errors/AuthError");
var logger_1 = require("../../shared/utils/logger");
// Role-based access control middleware
var requireRole = function (allowedRoles) {
    return function (req, res, next) {
        if (!req.user) {
            var err = AuthError_1.AuthError.invalidToken("User not authenticated");
            return next(err);
        }
        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                status: 403,
                data: null,
                error: {
                    message: "Access denied. Required roles: ".concat(allowedRoles.join(", ")),
                },
            });
        }
        logger_1.Logger.info("User ".concat(req.user.id, " authorized for role: ").concat(req.user.role));
        next();
    };
};
exports.requireRole = requireRole;
