"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = require("express");
var authMiddleware_1 = require("../middlewares/authMiddleware");
var requireRole_1 = require("../middlewares/requireRole");
var roles_1 = require("../../shared/lib/roles");
var asyncWrapper_1 = require("../../shared/utils/asyncWrapper");
var container_1 = require("../../config/container");
var router = (0, express_1.Router)();
/**
 * @swagger
 * /stats:
 *   get:
 *     tags: [Stats]
 *     summary: Get consolidated dashboard statistics
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Dashboard statistics
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 status:
 *                   type: number
 *                 data:
 *                   type: object
 *                   properties:
 *                     totalPatients:
 *                       type: integer
 *                     activeSessions:
 *                       type: integer
 *                     activemachines:
 *                       type: integer
 *                     staffCount:
 *                       type: integer
 *                     staffSublabel:
 *                       type: string
 *                 error:
 *                   nullable: true
 *                   type: object
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 */
router.get('/', authMiddleware_1.authMiddleware, (0, requireRole_1.requireRole)([roles_1.Role.ADMIN, roles_1.Role.DOCTOR, roles_1.Role.RECEPTIONIST]), (0, asyncWrapper_1.asyncWrapper)(container_1.statsController.getStats.bind(container_1.statsController)));
exports.default = router;
