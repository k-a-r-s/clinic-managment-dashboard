"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = void 0;
var Logger = /** @class */ (function () {
    function Logger() {
    }
    Logger.formatDate = function () {
        return new Date().toISOString();
    };
    Logger.colorize = function (color, text) {
        var colors = {
            reset: '\x1b[0m',
            red: '\x1b[31m',
            green: '\x1b[32m',
            yellow: '\x1b[33m',
            blue: '\x1b[34m',
            magenta: '\x1b[35m',
            cyan: '\x1b[36m',
            white: '\x1b[37m',
        };
        return "".concat(colors[color]).concat(text).concat(colors.reset);
    };
    Logger.info = function (message) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        console.log.apply(console, __spreadArray(["".concat(this.colorize('cyan', '[INFO]'), " ").concat(this.formatDate(), " - ").concat(message)], args, false));
    };
    Logger.error = function (message, error) {
        console.error("".concat(this.colorize('red', '[ERROR]'), " ").concat(this.formatDate(), " - ").concat(message), error || '');
    };
    Logger.warn = function (message) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        console.warn.apply(console, __spreadArray(["".concat(this.colorize('yellow', '[WARN]'), " ").concat(this.formatDate(), " - ").concat(message)], args, false));
    };
    Logger.success = function (message) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        console.log.apply(console, __spreadArray(["".concat(this.colorize('green', '[SUCCESS]'), " ").concat(this.formatDate(), " - ").concat(message)], args, false));
    };
    Logger.debug = function (message) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        if (process.env.NODE_ENV === 'development') {
            console.log.apply(console, __spreadArray(["".concat(this.colorize('magenta', '[DEBUG]'), " ").concat(this.formatDate(), " - ").concat(message)], args, false));
        }
    };
    Logger.http = function (method, path, statusCode, duration) {
        var color = statusCode >= 500 ? 'red'
            : statusCode >= 400 ? 'yellow'
                : statusCode >= 300 ? 'cyan'
                    : 'green';
        console.log("".concat(this.colorize('blue', '[HTTP]'), " ").concat(this.formatDate(), " - ").concat(this.colorize(color, method), " ").concat(path, " ").concat(this.colorize(color, String(statusCode)), " - ").concat(duration, "ms"));
    };
    return Logger;
}());
exports.Logger = Logger;
